Dit is de NS Actuele Vertrektijden applicatie

==================================
Gebruikershandleiding:
==================================

Stap 1: Start het programma op via de Homescreen van het NS automaat
Stap 2: Dubbelklik op een letter en er verschijnen verschillende stations die beginnen met het aangeklikte letter
Stap 3: DubbelKlik op uw gewenste station
Stap 4: U ziet nu onderaan de treinen die binnen een uur vertrekken vanaf dat station.
Stap 5: U kunt de stappen herhalen om een andere station te vinden.